export enum RoleEnum {
  WORKER = 'worker',
  BOSS = 'boss',
  ADMIN = 'admin',
}
